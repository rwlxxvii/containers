module.exports.ACCESS_LEVEL = { 
    'Restricted': 1,
    'Full': 2,
    'Manage': 3,
    'Owner': 4
}
