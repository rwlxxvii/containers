ALTER TABLE `collection` 
DROP COLUMN `description`;