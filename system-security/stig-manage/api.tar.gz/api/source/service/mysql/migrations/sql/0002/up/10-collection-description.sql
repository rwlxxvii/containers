ALTER TABLE `collection` 
ADD COLUMN `description` VARCHAR(255) NULL AFTER `name`;