ALTER TABLE `collection` 
DROP COLUMN `created`;
